# zerif-update-fix
Fix your zerif lite updates 
